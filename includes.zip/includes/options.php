<?php
if ( ! defined( 'ABSPATH' ) ) exit;

function wfm_adv_get_default_options(){
    return [
        'phone' => '5515997064008',
        'load_on_home' => 1,
        'recaptcha_enabled' => 0,
        'recaptcha_site_key' => '',
        'recaptcha_secret_key' => '',
        'style_bg_color' => '#ffffff',
        'style_input_bg' => '#ffffff',
        'style_btn_bg' => '#fea45a',
        'style_btn_hover' => '#e09450',
        'style_radius' => 15,
        'style_max_width' => 400,
        'style_alignment' => 'center',
        'style_button_text' => 'Entrar em Contato',
        'fields' => [
            ['id'=>'nome','label'=>'Nome','type'=>'text','placeholder'=>'Seu nome','required'=>1],
            ['id'=>'whatsapp','label'=>'Whatsapp','type'=>'phone','placeholder'=>'(DDD) 9XXXX-XXXX','required'=>1],
            ['id'=>'email','label'=>'Email','type'=>'email','placeholder'=>'seu@exemplo.com','required'=>1],
            ['id'=>'mensagem','label'=>'Mensagem','type'=>'textarea','placeholder'=>'Explique sua necessidade','required'=>1],
        ],
    ];
}

function wfm_adv_get_options(){
    $defaults = wfm_adv_get_default_options();
    $opts = get_option('wfm_adv_options', []);
    return wp_parse_args($opts, $defaults);
}
