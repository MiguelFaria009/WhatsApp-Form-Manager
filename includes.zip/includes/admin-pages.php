<?php
if ( ! defined( 'ABSPATH' ) ) exit;

add_action('admin_menu', function(){
    add_menu_page('WhatsApp Form', 'WhatsApp Form', 'manage_options', 'wfm-adv', 'wfm_adv_settings_page', 'dashicons-format-chat', 58);
    add_submenu_page('wfm-adv', 'Campos', 'Campos', 'manage_options', 'wfm-adv-fields', 'wfm_adv_fields_page');
    add_submenu_page('wfm-adv', 'Estilos', 'Estilos', 'manage_options', 'wfm-adv-style', 'wfm_adv_style_page');
});

add_action('admin_enqueue_scripts', function($hook){
    if (strpos($hook, 'wfm-adv') === false) return;
    wp_enqueue_style('wfm-adv-admin', WFM_ADV_PLUGIN_URL . 'assets/css/admin.css', [], WFM_ADV_VERSION);
    wp_enqueue_script('wfm-adv-admin', WFM_ADV_PLUGIN_URL . 'assets/js/admin.js', ['jquery'], WFM_ADV_VERSION, true);
    $opts = wfm_adv_get_options();
    wp_localize_script('wfm-adv-admin','wfmAdvAdmin', $opts);
});

function wfm_adv_settings_page(){
    if (!current_user_can('manage_options')) return;
    $opts = wfm_adv_get_options();
    if ($_POST && check_admin_referer('wfm_adv_save_settings')) {
        $save = [];
        $save['phone'] = sanitize_text_field($_POST['phone']);
        $save['load_on_home'] = !empty($_POST['load_on_home']) ? 1 : 0;
        update_option('wfm_adv_options', array_merge($opts, $save));
        $opts = wfm_adv_get_options();
        echo '<div class="updated"><p>Configurações salvas.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>WhatsApp Form — Geral</h1>
        <form method="post">
            <?php wp_nonce_field('wfm_adv_save_settings'); ?>
            <table class="form-table">
                <tr>
                    <th>Número WhatsApp</th>
                    <td><input type="text" name="phone" value="<?php echo esc_attr($opts['phone']); ?>" class="regular-text" /></td>
                </tr>
                <tr>
                    <th>Carregar apenas na home?</th>
                    <td><label><input type="checkbox" name="load_on_home" value="1" <?php checked(1,$opts['load_on_home']); ?>/> Sim</label></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
        <hr/>
        <p>Use <code>[whatsapp_form]</code> para inserir o formulário em páginas.</p>
    </div>
    <?php
}

function wfm_adv_fields_page(){
    if (!current_user_can('manage_options')) return;
    $opts = wfm_adv_get_options();
    if ($_POST && check_admin_referer('wfm_adv_save_fields')) {
        $fields_json = wp_unslash($_POST['fields_json']);
        $decoded = json_decode($fields_json, true);
        if (is_array($decoded)) {
            $opts['fields'] = $decoded;
            update_option('wfm_adv_options', $opts);
            echo '<div class="updated"><p>Campos salvos.</p></div>';
        } else {
            echo '<div class="error"><p>JSON inválido.</p></div>';
        }
    }
    ?>
    <div class="wrap">
        <h1>Campos do Formulário</h1>
        <div id="wfm-fields-app">
            <p class="description">Adicione/edite os campos do formulário. A interface salva como JSON (sem precisar codar). </p>
            <div id="wfm-fields-list"></div>
            <button class="button" id="wfm-add-field">Adicionar Campo</button>

            <form method="post" style="margin-top:20px;">
                <?php wp_nonce_field('wfm_adv_save_fields'); ?>
                <input type="hidden" id="fields_json" name="fields_json" />
                <p>Preview (JSON) — caso precise editar manualmente:</p>
                <textarea id="fields_json_view" rows="8" style="width:100%;"><?php echo esc_textarea(json_encode($opts['fields'], JSON_UNESCAPED_UNICODE)); ?></textarea>
                <?php submit_button('Salvar Campos'); ?>
            </form>
        </div>
    </div>
    <?php
}

function wfm_adv_style_page(){
    if (!current_user_can('manage_options')) return;
    $opts = wfm_adv_get_options();
    if ($_POST && check_admin_referer('wfm_adv_save_style')) {
        $save = [];
        $save['style_bg_color'] = sanitize_text_field($_POST['style_bg_color']);
        $save['style_input_bg'] = sanitize_text_field($_POST['style_input_bg']);
        $save['style_btn_bg'] = sanitize_text_field($_POST['style_btn_bg']);
        $save['style_btn_hover'] = sanitize_text_field($_POST['style_btn_hover']);
        $save['style_radius'] = intval($_POST['style_radius']);
        $save['style_max_width'] = intval($_POST['style_max_width']);
        $save['style_alignment'] = sanitize_text_field($_POST['style_alignment']);
        $save['style_button_text'] = sanitize_text_field($_POST['style_button_text']);
        $opts = array_merge($opts, $save);
        update_option('wfm_adv_options', $opts);
        echo '<div class="updated"><p>Estilos salvos.</p></div>';
    }
    ?>
    <div class="wrap">
        <h1>Estilos do Formulário</h1>
        <form method="post">
            <?php wp_nonce_field('wfm_adv_save_style'); ?>
            <table class="form-table">
                <tr>
                    <th>Cor de fundo</th>
                    <td><input type="text" name="style_bg_color" class="wfm-color" value="<?php echo esc_attr($opts['style_bg_color']); ?>" /></td>
                </tr>
                <tr>
                    <th>Cor dos inputs</th>
                    <td><input type="text" name="style_input_bg" class="wfm-color" value="<?php echo esc_attr($opts['style_input_bg']); ?>" /></td>
                </tr>
                <tr>
                    <th>Cor do botão</th>
                    <td><input type="text" name="style_btn_bg" class="wfm-color" value="<?php echo esc_attr($opts['style_btn_bg']); ?>" /></td>
                </tr>
                <tr>
                    <th>Cor do hover</th>
                    <td><input type="text" name="style_btn_hover" class="wfm-color" value="<?php echo esc_attr($opts['style_btn_hover']); ?>" /></td>
                </tr>
                <tr>
                    <th>Border radius (px)</th>
                    <td><input type="number" name="style_radius" value="<?php echo esc_attr($opts['style_radius']); ?>" /></td>
                </tr>
                <tr>
                    <th>Largura máxima (px)</th>
                    <td><input type="number" name="style_max_width" value="<?php echo esc_attr($opts['style_max_width']); ?>" /></td>
                </tr>
                <tr>
                    <th>Alinhamento</th>
                    <td>
                        <select name="style_alignment">
                            <option value="left" <?php selected('left', $opts['style_alignment']); ?>>Esquerda</option>
                            <option value="center" <?php selected('center', $opts['style_alignment']); ?>>Centro</option>
                            <option value="right" <?php selected('right', $opts['style_alignment']); ?>>Direita</option>
                        </select>
                    </td>
                </tr>
                <tr>
                    <th>Texto do botão</th>
                    <td><input type="text" name="style_button_text" value="<?php echo esc_attr($opts['style_button_text']); ?>" /></td>
                </tr>
            </table>
            <?php submit_button(); ?>
        </form>
    </div>
    <?php
}
