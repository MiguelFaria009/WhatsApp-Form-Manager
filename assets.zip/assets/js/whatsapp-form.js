(function(){
document.addEventListener('DOMContentLoaded', function(){
    var form = document.getElementById('whatsappForm');
    if (!form) return;
    var data = window.wfmAdvData || {};
    var phone = data.phone || '';
    var fields = data.fields || [];

    function collectFields() {
        var parts = [];
        fields.forEach(function(f){
            var el = document.getElementById(f.id);
            if (!el) return;
            var val = el.value || '';
            parts.push('*' + f.label + '*: ' + val);
        });
        return parts.join('\n');
    }

    function openWhatsApp(){
        var texto = collectFields();
        var encoded = encodeURIComponent(texto);
        var url = 'https://wa.me/' + phone + '?text=' + encoded;
        window.open(url, '_blank');
    }

    form.addEventListener('submit', function(e){
        e.preventDefault();
        if (data.recaptcha_enabled && typeof grecaptcha !== 'undefined') {
            try {
                grecaptcha.ready(function(){
                    grecaptcha.execute(data.recaptcha_site_key, {action: 'submit'}).then(function(token){
                        if (token) openWhatsApp();
                        else alert('Falha no reCAPTCHA.');
                    });
                });
            } catch(err){
                openWhatsApp();
            }
        } else {
            openWhatsApp();
        }
    });
});
})();