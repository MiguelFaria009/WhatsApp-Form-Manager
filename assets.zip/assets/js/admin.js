(function($){
    var opts = window.wfmAdvAdmin || {};
    var fields = opts.fields || [];

    function renderList(){
        var $list = $('#wfm-fields-list');
        $list.empty();
        if (!fields.length) $list.append('<p>Nenhum campo. Clique em "Adicionar Campo".</p>');
        fields.forEach(function(f, idx){
            var html = '<div class="wfm-field-item" data-idx="'+idx+'">' +
                '<div><strong>'+f.label+'</strong> <em>['+f.type+']</em> ' +
                (f.required ? '<span class="wfm-required">Obrigatório</span>' : '') +
                '<div class="wfm-actions" style="display:inline-block;margin-left:12px"><button class="button wfm-edit">Editar</button> <button class="button wfm-delete">Excluir</button></div>' +
                '</div></div>';
            $list.append(html);
        });
        $('#fields_json_view').val(JSON.stringify(fields, null, 2));
    }

    function openEditor(f, idx){
        var modal = $('<div class="wfm-modal"></div>');
        var form = $('<div class="wfm-modal-inner">' +
            '<label>Label<br><input type="text" id="wfm_field_label" value="'+(f?f.label:'')+'"></label><br/>' +
            '<label>Id (a-z0-9_-)<br><input type="text" id="wfm_field_id" value="'+(f?f.id:'')+'"></label><br/>' +
            '<label>Tipo<br><select id="wfm_field_type"><option value="text">Texto</option><option value="email">Email</option><option value="phone">Phone</option><option value="textarea">Textarea</option></select></label><br/>' +
            '<label>Placeholder<br><input type="text" id="wfm_field_placeholder" value="'+(f? (f.placeholder||'') : '')+'"></label><br/>' +
            '<label><input type="checkbox" id="wfm_field_required" '+(f && f.required ? 'checked' : '')+'> Obrigatório</label><br/>' +
            '<p><button class="button button-primary" id="wfm-save-field">Salvar</button> <button class="button wfm-cancel">Cancelar</button></p>' +
            '</div>');
        modal.append(form);
        $('body').append(modal);
        if (f) $('#wfm_field_type').val(f.type);
        $('#wfm-save-field').on('click', function(){
            var newf = {
                id: $('#wfm_field_id').val().trim(),
                label: $('#wfm_field_label').val().trim(),
                type: $('#wfm_field_type').val(),
                placeholder: $('#wfm_field_placeholder').val(),
                required: $('#wfm_field_required').is(':checked') ? 1 : 0
            };
            if (!newf.id || !newf.label){
                alert('Id e Label são obrigatórios.');
                return;
            }
            if (idx === undefined || idx === null){
                fields.push(newf);
            } else {
                fields[idx] = newf;
            }
            $('.wfm-modal').remove();
            renderList();
        });
        $('.wfm-cancel').on('click', function(){ $('.wfm-modal').remove(); });
    }

    $(document).ready(function(){
        renderList();
        $('#wfm-add-field').on('click', function(e){ e.preventDefault(); openEditor(); });
        $('#wfm-fields-list').on('click', '.wfm-delete', function(){
            var idx = $(this).closest('.wfm-field-item').data('idx');
            if (confirm('Excluir este campo?')) {
                fields.splice(idx,1);
                renderList();
            }
        });
        $('#wfm-fields-list').on('click', '.wfm-edit', function(){
            var idx = $(this).closest('.wfm-field-item').data('idx');
            openEditor(fields[idx], idx);
        });

        $('form').on('submit', function(){
            $('#fields_json').val(JSON.stringify(fields));
        });

        $('#fields_json_view').on('change', function(){
            try {
                var parsed = JSON.parse($(this).val());
                if (Array.isArray(parsed)) {
                    fields = parsed;
                    renderList();
                } else {
                    alert('JSON deve ser um array de campos.');
                }
            } catch(e){
                alert('JSON inválido: ' + e.message);
            }
        });
    });
})(jQuery);
